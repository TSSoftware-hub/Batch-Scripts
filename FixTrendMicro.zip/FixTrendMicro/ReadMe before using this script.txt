Copy this to Desktop and run from there as Administrator!!!!!

==== What it does ====

I. Renames files:

1. tmactmon.sys -> tmactmon.sys.bak
2. tmcomm.sys -> tmcomm.sys.bak
3. tmevtmgr.sys -> tmevtmgr.sys.bak

II. Creates folders

1. tmactmon.sys
2. tmcomm.sys
3. tmevtmgr.sys

III. Restarts the machine


==== How to use this =====

1. Run the first part of the script FixTrendMicro_p1.bat as administrator
This will restart your machine (sometimes you need to do this after renaming files and creating folders)

2. Run the second part of the script FixTrendMicro_p2.bat as administrator.